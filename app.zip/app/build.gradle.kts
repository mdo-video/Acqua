plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
val vc = (project.findProperty("vc") as String?)?.toInt() ?: 1
val repo = (project.findProperty("ghRepo") as String?) ?: ""
android {
    namespace = "app.acqua"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.acqua"
        minSdk = 26
        targetSdk = 34
        versionCode = vc
        versionName = "1.0.$vc"
        buildConfigField("String", "GH_REPO", "\"$repo\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    signingConfigs {
        create("rel") {
            storeFile = file("acqua-fixed.jks")
            storePassword = "acqua123"
            keyAlias = "acqua"
            keyPassword = "acqua123"
        }
    }
    buildTypes { release { signingConfig = signingConfigs.getByName("rel"); isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
}
