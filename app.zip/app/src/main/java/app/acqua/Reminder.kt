package app.acqua

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val m = Model(applicationContext)
        val left = m.goalMl - m.todayMl()
        if (m.notify && left > 0) {
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("acqua", "Promemoria acqua", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(
                applicationContext, 0, Intent(applicationContext, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(applicationContext, "acqua")
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("È ora di bere")
                .setContentText("Ti mancano ancora ${litri(left)} L per oggi")
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(1, n)
        }
        Reminder.schedule(applicationContext)
        return Result.success()
    }
}

fun litri(ml: Int): String = String.format(Locale.ITALY, "%.1f", ml / 1000.0)

object Reminder {
    fun schedule(c: Context) {
        val m = Model(c)
        val wm = WorkManager.getInstance(c)
        if (!m.notify || !m.profileDone) { wm.cancelUniqueWork("rem"); return }
        wm.enqueueUniqueWork(
            "rem", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(nextDelay(m), TimeUnit.MILLISECONDS).build()
        )
    }

    fun nextDelay(m: Model): Long {
        val now = Calendar.getInstance()
        fun at(day: Int, h: Int) = (now.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, day)
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        var h = m.startH
        while (h <= m.endH) {
            val t = at(0, h)
            if (t > now.timeInMillis + 60_000) return t - now.timeInMillis
            h += m.every
        }
        return at(1, m.startH) - now.timeInMillis
    }

    fun nextTime(m: Model): String =
        SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(System.currentTimeMillis() + nextDelay(m)))
}
