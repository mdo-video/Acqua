package app.acqua

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val m = Model.get(applicationContext)
        val done = m.todayMl()
        val left = m.goalMl - done
        if (m.notify && left > 0 && done < Reminder.expected(m)) {
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("acqua", "Promemoria acqua", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(
                applicationContext, 0, Intent(applicationContext, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val addPi = PendingIntent.getBroadcast(
                applicationContext, 1,
                Intent(applicationContext, AddReceiver::class.java).putExtra("ml", 250),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val act = Notification.Action.Builder(
                Icon.createWithResource(applicationContext, R.drawable.ic_fg), "+250 ml", addPi
            ).build()
            val add2 = PendingIntent.getBroadcast(
                applicationContext, 2,
                Intent(applicationContext, AddReceiver::class.java).putExtra("ml", 500),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val act2 = Notification.Action.Builder(
                Icon.createWithResource(applicationContext, R.drawable.ic_fg), "+500 ml", add2
            ).build()
            val n = Notification.Builder(applicationContext, "acqua")
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("È ora di bere")
                .setContentText("Ti mancano ancora ${litri(left)} L per oggi")
                .addAction(act).addAction(act2)
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(1, n)
        }
        Reminder.schedule(applicationContext)
        return Result.success()
    }
}

fun litri(ml: Int): String = String.format(Locale.ITALY, "%.1f", ml / 1000.0)

object Reminder {
    fun schedule(c: Context) {
        val m = Model.get(c)
        Weekly.schedule(c)
        val wm = WorkManager.getInstance(c)
        if (!m.notify || !m.profileDone) { wm.cancelUniqueWork("rem"); return }
        wm.enqueueUniqueWork(
            "rem", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(nextDelay(m), TimeUnit.MILLISECONDS).build()
        )
    }

    // Quanto dovresti aver bevuto a quest'ora (compresa la quota di questo promemoria)
    fun expected(m: Model): Int {
        val n = Calendar.getInstance()
        val h = n.get(Calendar.HOUR_OF_DAY) + n.get(Calendar.MINUTE) / 60.0
        val step = m.everyMin / 60.0
        val span = (m.endH - m.startH) + step
        val f = ((h - m.startH + step) / span).coerceIn(0.0, 1.0)
        return (m.goalMl * f).toInt()
    }

    fun nextDelay(m: Model): Long {
        val now = Calendar.getInstance()
        fun at(day: Int, min: Int): Long {
            val c = now.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, day)
            c.set(Calendar.HOUR_OF_DAY, min / 60)
            c.set(Calendar.MINUTE, min % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }
        for (day in 0..1) {
            var t = m.startH * 60
            while (t <= m.endH * 60) {
                val quiet = m.quietOn && t >= m.quietFrom * 60 && t < m.quietTo * 60
                val ts = at(day, t)
                if (!quiet && ts > now.timeInMillis + 60_000) return ts - now.timeInMillis
                t += m.everyMin
            }
        }
        return at(1, m.startH * 60) - now.timeInMillis
    }

    fun nextTime(m: Model): String =
        SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(System.currentTimeMillis() + nextDelay(m)))
}
