package app.acqua

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    fun ask(
        key: String, system: String, history: List<Pair<Boolean, String>>,
        image: String? = null, userText: String? = null, model: String = "gemini-3.8-flash"
    ): JSONObject {
        val contents = JSONArray()
        val h = history.takeLast(12)
        h.forEachIndexed { idx, (u, t) ->
            val parts = JSONArray()
            if (image != null && u && idx == h.size - 1) {
                parts.put(JSONObject().put("text", userText ?: t))
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", image)))
            } else {
                parts.put(JSONObject().put("text", t))
            }
            contents.put(JSONObject().put("role", if (u) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            .toString()
        val errs = mutableListOf<String>()
        val models = listOf(model.trim(), "gemini-flash-latest", "gemini-3.5-flash").filter { it.isNotEmpty() }.distinct()
        for (md in models) {
            try {
                return parse(call("https://generativelanguage.googleapis.com/v1beta/models/$md:generateContent", key, body))
            } catch (e: Exception) {
                errs += md + ": " + (e.message ?: "errore")
            }
        }
        throw Exception(errs.joinToString("\n"))
    }

    private fun call(url: String, key: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code >= 400) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw Exception("HTTP $code ${m.take(110)}")
        }
        return txt
    }

    private fun parse(txt: String): JSONObject {
        val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var s = ""
        for (i in 0 until parts.length()) s += parts.getJSONObject(i).optString("text", "")
        s = s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            JSONObject(s)
        } catch (e: Exception) {
            JSONObject().put("reply", s).put("actions", JSONArray())
        }
    }
}
