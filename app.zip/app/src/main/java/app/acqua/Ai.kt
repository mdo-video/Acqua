package app.acqua

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    @Volatile private var pick = 0
    private val targets = listOf(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent",
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        "https://aiplatform.googleapis.com/v1/publishers/google/models/gemini-2.5-flash:generateContent"
    )

    fun ask(key: String, system: String, history: List<Pair<Boolean, String>>): JSONObject {
        val contents = JSONArray()
        history.takeLast(12).forEach { (u, t) ->
            contents.put(
                JSONObject().put("role", if (u) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            .toString()
        val errs = mutableListOf<String>()
        val order = targets.indices.sortedBy { if (it == pick) 0 else 1 }
        for (i in order) {
            try {
                val r = parse(call(targets[i], key, body))
                pick = i
                return r
            } catch (e: Exception) {
                errs += e.message ?: "errore"
            }
        }
        throw Exception(errs.joinToString(" | "))
    }

    private fun call(url: String, key: String, body: String): String {
        val vertex = url.contains("aiplatform")
        val c = URL(if (vertex) "$url?key=$key" else url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        if (!vertex) c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code >= 400) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw Exception("HTTP $code ${m.take(140)}")
        }
        return txt
    }

    private fun parse(txt: String): JSONObject {
        val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var s = ""
        for (i in 0 until parts.length()) s += parts.getJSONObject(i).optString("text", "")
        s = s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            JSONObject(s)
        } catch (e: Exception) {
            JSONObject().put("reply", s).put("actions", JSONArray())
        }
    }
}
