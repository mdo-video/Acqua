package app.acqua

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    fun ask(
        key: String, system: String, history: List<Pair<Boolean, String>>,
        image: String? = null, userText: String? = null, model: String = "gemini-flash-latest"
    ): JSONObject {
        val contents = JSONArray()
        val h = history.takeLast(12)
        h.forEachIndexed { idx, (u, t) ->
            val parts = JSONArray()
            if (image != null && u && idx == h.size - 1) {
                parts.put(JSONObject().put("text", userText ?: t))
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", image)))
            } else {
                parts.put(JSONObject().put("text", t))
            }
            contents.put(JSONObject().put("role", if (u) "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            .toString()
        val codes = mutableListOf<Int>()
        val errs = mutableListOf<String>()
        val models = listOf("gemini-flash-latest", "gemini-flash-lite-latest", model.trim(), "gemini-3.5-flash")
            .filter { it.isNotEmpty() }.distinct()
        for (md in models) {
            for (attempt in 0..1) {
                try {
                    return parse(call("https://generativelanguage.googleapis.com/v1beta/models/$md:generateContent", key, body))
                } catch (e: ApiErr) {
                    codes += e.code
                    errs += md + ": " + e.message
                    if (e.code == 503 && attempt == 0) { Thread.sleep(1500); continue }
                    break
                } catch (e: Exception) {
                    codes += 0
                    errs += md + ": " + (e.message ?: "errore")
                    break
                }
            }
        }
        throw Exception(
            when {
                codes.isNotEmpty() && codes.all { it == 429 } -> "Quota Gemini esaurita. Riprova più tardi o usa un'altra chiave."
                codes.any { it == 400 || it == 403 } -> "Chiave API non valida o non autorizzata."
                codes.any { it == 503 || it == 0 } && codes.none { it == 429 } -> "Gemini è sovraccarico. Riprova tra poco."
                else -> "Gemini non disponibile ora (quota o sovraccarico). Riprova tra poco."
            }
        )
    }

    class ApiErr(val code: Int, msg: String) : Exception(msg)

    private fun call(url: String, key: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code >= 400) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw ApiErr(code, "HTTP $code ${m.take(80)}")
        }
        return txt
    }

    private fun parse(txt: String): JSONObject {
        val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        var s = ""
        for (i in 0 until parts.length()) s += parts.getJSONObject(i).optString("text", "")
        s = s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            JSONObject(s)
        } catch (e: Exception) {
            JSONObject().put("reply", s).put("actions", JSONArray())
        }
    }
}
