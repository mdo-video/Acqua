package app.acqua

import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AddReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Model.get(c).addEntry(i.getIntExtra("ml", 250))
        c.getSystemService(NotificationManager::class.java).cancel(1)
    }
}

class WaterWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, views(c)) }
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val m = Model.get(c)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.w_text, "${litri(m.todayMl())} / ${litri(m.goalMl)} L")
            val add = PendingIntent.getBroadcast(
                c, 2, Intent(c, AddReceiver::class.java).putExtra("ml", 250),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_add, add)
            val open = PendingIntent.getActivity(
                c, 3, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_root, open)
            return rv
        }

        fun refresh(c: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(c)
                val ids = mgr.getAppWidgetIds(ComponentName(c, WaterWidget::class.java))
                ids.forEach { mgr.updateAppWidget(it, views(c)) }
            } catch (e: Exception) {
            }
        }
    }
}
