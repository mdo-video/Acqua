package app.acqua

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Medal(val title: String, val desc: String, val ok: Boolean)

object Badges {
    private fun fmt() = SimpleDateFormat("yyyyMMdd", Locale.ITALY)

    fun totals(m: Model): Map<String, Int> {
        val sf = fmt()
        return m.entries.groupBy { sf.format(Date(it.ts)) }.mapValues { e -> e.value.sumOf { it.ml } }
    }

    fun streak(m: Model): Int {
        val t = totals(m)
        val sf = fmt()
        val c = Calendar.getInstance()
        if ((t[sf.format(c.time)] ?: 0) < m.goalMl) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while ((t[sf.format(c.time)] ?: 0) >= m.goalMl && n < 3650) { n++; c.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }

    fun best(m: Model): Int {
        val t = totals(m)
        if (t.isEmpty()) return 0
        val sf = fmt()
        val c = Calendar.getInstance()
        c.time = sf.parse(t.keys.minOrNull()!!)!!
        val end = Calendar.getInstance()
        var run = 0
        var best = 0
        while (!c.after(end)) {
            if ((t[sf.format(c.time)] ?: 0) >= m.goalMl) { run++; if (run > best) best = run } else run = 0
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return best
    }

    fun medals(m: Model): List<Medal> {
        val b = best(m)
        val tot = m.entries.sumOf { it.ml } / 1000
        return listOf(
            Medal("Primo traguardo", "Obiettivo raggiunto 1 giorno", b >= 1),
            Medal("3 giorni di fila", "Serie di 3 giorni", b >= 3),
            Medal("Settimana d'oro", "7 giorni di fila", b >= 7),
            Medal("Un mese di costanza", "30 giorni di fila", b >= 30),
            Medal("50 litri", "50 L bevuti in totale", tot >= 50),
            Medal("100 litri", "100 L bevuti in totale", tot >= 100),
            Medal("500 litri", "500 L bevuti in totale", tot >= 500)
        )
    }
}

@Composable
fun StreakCard(m: Model) {
    val cs = MaterialTheme.colorScheme
    val s = Badges.streak(m)
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Serie attuale", color = cs.onSurfaceVariant)
                Text(if (s == 1) "1 giorno" else "$s giorni", style = MaterialTheme.typography.titleLarge)
            }
            Text("Record: ${Badges.best(m)}", color = cs.onSurfaceVariant)
        }
    }
}

@Composable
fun WeatherCard(m: Model) {
    val t = m.tempMax ?: return
    if (!m.weatherOn) return
    val cs = MaterialTheme.colorScheme
    val extra = when { t >= 30 -> 500; t >= 25 -> 250; else -> 0 }
    val msg = if (extra > 0) "Oggi massima ${t}°C: aggiungi circa $extra ml al tuo obiettivo."
    else "Oggi massima ${t}°C: il tuo obiettivo va bene così."
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer),
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
    ) { Text(msg, Modifier.padding(16.dp)) }
}

@Composable
fun BadgesSection(m: Model) {
    val cs = MaterialTheme.colorScheme
    Text("Badge", Modifier.padding(top = 24.dp), style = MaterialTheme.typography.titleMedium)
    Badges.medals(m).chunked(2).forEach { r ->
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            r.forEach { b ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (b.ok) cs.primaryContainer else cs.surfaceContainer,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        val c = if (b.ok) cs.onPrimaryContainer else cs.onSurfaceVariant
                        Text(b.title, style = MaterialTheme.typography.titleSmall, color = c)
                        Text(if (b.ok) "Ottenuto" else b.desc, style = MaterialTheme.typography.bodySmall, color = c)
                    }
                }
            }
            if (r.size < 2) Spacer(Modifier.weight(1f))
        }
    }
}
