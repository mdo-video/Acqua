package app.acqua

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    lateinit var model: Model
    private var syncing = false
    private var again = false

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        try {
            val res = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(r.data)
            sync(res.accessToken ?: "")
        } catch (e: Exception) {
            syncing = false
            model.syncStatus = "Accesso annullato"
        }
    }
    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) askAi(t)
    }
    private var photoUri: Uri? = null
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = photoUri
        if (ok && u != null) attach(u)
    }
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) attach(uri)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        model = Model.get(this)
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        Reminder.schedule(this)
        setContent { App(model, this) }
        if (model.linked) startSync()
        if (model.weatherOn) refreshWeather()
        checkUpdate()
    }

    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) refreshWeather() else { model.weatherOn = false; model.save(); model.wxStatus = "Permesso posizione negato" }
    }

    fun enableWeather() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) refreshWeather()
        else locLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    fun refreshWeather() {
        Thread {
            try {
                val t = Weather.tempMax(this)
                runOnUiThread {
                    if (t != null) { model.tempMax = t; model.wxStatus = "" }
                    else model.wxStatus = "Posizione non disponibile: apri Maps un istante e riprova"
                }
            } catch (e: Exception) {
                runOnUiThread { model.wxStatus = "Meteo non disponibile" }
            }
        }.start()
    }

    fun add(ml: Int, ts: Long = System.currentTimeMillis()) {
        model.lastAdded = model.addEntry(ml, ts)
        if (model.linked) startSync()
    }

    fun remove(e: Entry) {
        model.entries = model.entries - e
        model.deleted = model.deleted + e.ts
        if (model.lastAdded == e) model.lastAdded = null
        model.save()
        if (model.linked) startSync()
    }

    fun startSync() {
        if (syncing) { again = true; return }
        syncing = true
        val req = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.appdata"))).build()
        Identity.getAuthorizationClient(this).authorize(req)
            .addOnSuccessListener { res ->
                if (res.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(res.pendingIntent!!.intentSender).build())
                } else sync(res.accessToken ?: "")
            }
            .addOnFailureListener {
                syncing = false
                model.syncStatus = "Sync non disponibile: ${it.message}"
            }
    }

    private fun sync(token: String) {
        model.syncStatus = "Sincronizzo..."
        Thread {
            try {
                val r = Sync.run(token, SyncData(model.entries, model.deleted, model.convs, model.delConvs))
                runOnUiThread {
                    model.deleted = model.deleted + r.deleted
                    model.entries = mergeEntries(r.entries, model.entries).filter { it.ts !in model.deleted }
                    model.applySyncConvs(r.convs, r.delConvs)
                    model.linked = true
                    model.save()
                    model.syncStatus = "Sincronizzato"
                    endSync()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    model.syncStatus = "Errore sync: ${e.message}"
                    syncing = false
                    again = false
                }
            }
        }.start()
    }

    private fun endSync() {
        syncing = false
        if (again) { again = false; startSync() }
    }

    fun checkUpdate() {
        if (BuildConfig.GH_REPO.isEmpty()) { model.updStatus = "Repository non configurata"; return }
        model.updStatus = "Controllo..."
        Thread {
            try {
                val r = Update.latest(BuildConfig.GH_REPO)
                runOnUiThread {
                    if (r != null && r.first > BuildConfig.VERSION_CODE) {
                        model.updateUrl = r.second
                        model.updStatus = "Disponibile la versione 1.0.${r.first}"
                    } else model.updStatus = "App aggiornata"
                }
            } catch (e: Exception) {
                runOnUiThread { model.updStatus = "Errore: ${e.message}" }
            }
        }.start()
    }

    fun installUpdate() {
        val u = model.updateUrl ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            model.updStatus = "Consenti l'installazione e riprova"
            return
        }
        model.updStatus = "Download..."
        Thread {
            try {
                val f = Update.download(this, u)
                runOnUiThread { Update.install(this, f); model.updStatus = "" }
            } catch (e: Exception) {
                runOnUiThread { model.updStatus = "Errore: ${e.message}" }
            }
        }.start()
    }

    private fun shareFile(f: File, mime: String, title: String) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val send = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri("", uri)
        val chooser = Intent.createChooser(send, title)
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(chooser)
    }

    fun exportPdf(per: Period = Periods.lastDays(30)) {
        model.reportStatus = "Creo il report..."
        Thread {
            try {
                val f = Report.build(this, model, per)
                runOnUiThread {
                    shareFile(f, "application/pdf", "Condividi il report")
                    model.reportStatus = ""
                }
            } catch (e: Exception) {
                runOnUiThread { model.reportStatus = "Errore report: ${e.message}" }
            }
        }.start()
    }

    fun exportCsv(per: Period = Periods.lastDays(30)) {
        model.reportStatus = "Creo il file CSV..."
        Thread {
            try {
                val f = Report.csv(this, model, per)
                runOnUiThread {
                    shareFile(f, "text/csv", "Condividi il CSV")
                    model.reportStatus = ""
                }
            } catch (e: Exception) {
                runOnUiThread { model.reportStatus = "Errore CSV: ${e.message}" }
            }
        }.start()
    }

    // ---------- Assistente AI ----------

    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Parla ora")
        try {
            voiceLauncher.launch(i)
        } catch (e: Exception) {
            model.addMsg(false, "Riconoscimento vocale non disponibile su questo telefono.")
        }
    }

    fun takePhoto() {
        val f = File(cacheDir, "foto.jpg")
        f.delete()
        f.createNewFile()
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        photoUri = uri
        try {
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            model.addMsg(false, "Fotocamera non disponibile.")
        }
    }

    fun pickPhoto() {
        galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private fun attach(uri: Uri) {
        Thread {
            val b = Media.load(this, uri)
            runOnUiThread {
                if (b != null) model.pendingPhoto = b else model.addMsg(false, "Non riesco a leggere la foto.")
            }
        }.start()
    }

    fun askAi(text: String) {
        val photo = model.pendingPhoto
        model.pendingPhoto = null
        model.proposal = null
        if (text.isBlank() && photo == null) return
        val shown = if (photo != null) "📷 " + text.ifBlank { "Foto" } else text
        model.addMsg(true, shown)
        if (model.aiKey.isBlank()) {
            model.addMsg(false, "Inserisci prima la chiave API in Impostazioni.")
            return
        }
        model.aiBusy = true
        val hist = model.chat.toList()
        val sys = aiSystem()
        val key = model.aiKey
        val aiModel = model.aiModel
        Thread {
            try {
                var img: String? = null
                var userText: String? = null
                if (photo != null) {
                    img = Media.base64(photo)
                    val code = Media.barcode(photo)
                    val extra = if (code != null) Media.lookup(code) + "\n" else "Nessun codice a barre leggibile nella foto.\n"
                    userText = extra + text.ifBlank { "Stima quanta acqua o bevanda c'è in questa foto." }
                }
                val r = Ai.ask(key, sys, hist, img, userText, aiModel)
                runOnUiThread {
                    val acts = r.optJSONArray("actions") ?: JSONArray()
                    val notes = mutableListOf<String>()
                    for (i in 0 until acts.length()) {
                        val o = acts.optJSONObject(i) ?: continue
                        runAction(o)?.let { notes += it }
                    }
                    val reply = r.optString("reply", "").ifBlank { "Fatto." }
                    model.addMsg(false, (listOf(reply) + notes).joinToString("\n"))
                    model.aiBusy = false
                    if (model.linked) startSync()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    model.addMsg(false, "Errore: ${e.message}")
                    model.aiBusy = false
                }
            }
        }.start()
    }

    private fun runAction(o: JSONObject): String? {
        val m = model
        when (o.optString("type")) {
            "add" -> {
                val ml = o.optInt("ml", 0)
                if (ml !in 1..5000) return "Quantità non valida."
                val ago = o.optInt("minutes_ago", 0).coerceIn(0, 1440)
                add(ml, System.currentTimeMillis() - ago * 60_000L)
            }
            "remove_last" -> {
                val s = startOfDay(System.currentTimeMillis())
                val e = m.entries.filter { it.ts >= s }.maxByOrNull { it.ts } ?: return "Nessuna bevuta di oggi da annullare."
                remove(e)
            }
            "clear_today" -> {
                val s = startOfDay(System.currentTimeMillis())
                m.deleted = m.deleted + m.entries.filter { it.ts >= s }.map { it.ts }
                m.entries = m.entries.filter { it.ts < s }
                m.lastAdded = null
                m.save()
                if (m.linked) startSync()
            }
            "set_goal" -> {
                val ml = o.optInt("ml", 0)
                if (ml !in 1000..6000) return "Obiettivo non valido."
                m.goalMl = ml
                m.save()
            }
            "set_profile" -> {
                val kg = o.optInt("kg", 0)
                if (kg !in 30..200) return "Peso non valido."
                val act = o.optInt("activity", m.activity).coerceIn(0, 2)
                m.weight = kg
                m.activity = act
                m.goalMl = calcGoal(kg, act)
                m.save()
            }
            "set_reminders" -> {
                if (o.has("enabled")) m.notify = o.optBoolean("enabled", m.notify)
                val st = o.optInt("start", m.startH).coerceIn(5, 22)
                val en = o.optInt("end", m.endH).coerceIn(st + 1, 23)
                val evMin = if (o.has("every_minutes")) o.optInt("every_minutes")
                else if (o.has("every")) o.optInt("every") * 60 else m.everyMin
                m.startH = st
                m.endH = en
                m.everyMin = evMin.coerceIn(30, 360)
                if (o.has("quiet_enabled")) m.quietOn = o.optBoolean("quiet_enabled")
                if (o.has("quiet_from")) m.quietFrom = o.optInt("quiet_from").coerceIn(5, 22)
                if (o.has("quiet_to")) m.quietTo = o.optInt("quiet_to").coerceIn(m.quietFrom + 1, 23)
                m.save()
                Reminder.schedule(this)
            }
            "propose_add" -> {
                val ml = o.optInt("ml", 0)
                if (ml !in 1..5000) return "Quantità non valida."
                m.proposal = ml
            }
            "save_favorite" -> {
                val nm = o.optString("name").trim().take(16)
                val ml = o.optInt("ml", 0)
                if (nm.isEmpty() || ml !in 20..5000) return "Preferito non valido."
                if (m.favs.size >= 6 && m.favs.none { it.first.equals(nm, true) }) return "Hai già 6 preferiti: eliminane uno."
                m.favs = m.favs.filter { !it.first.equals(nm, true) } + (nm to ml)
                m.save()
            }
            "remove_favorite" -> {
                val nm = o.optString("name").trim()
                val before = m.favs.size
                m.favs = m.favs.filter { !it.first.equals(nm, true) }
                if (m.favs.size == before) return "Preferito non trovato."
                m.save()
            }
            "set_theme" -> {
                m.theme = o.optInt("value", 0).coerceIn(0, 2)
                m.save()
            }
            "sync" -> startSync()
            "export_pdf" -> exportPdf(Periods.fromAi(o))
            "export_csv" -> exportCsv(Periods.fromAi(o))
            else -> return "Azione non riconosciuta."
        }
        return null
    }

    private fun aiSystem(): String {
        val m = model
        val f = SimpleDateFormat("yyyyMMdd", Locale.ITALY)
        val tot = m.entries.groupBy { f.format(Date(it.ts)) }.mapValues { en -> en.value.sumOf { it.ml } }
        val week = (6 downTo 0).joinToString(", ") { d ->
            val day = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -d) }.time
            f.format(day) + ": " + (tot[f.format(day)] ?: 0) + " ml"
        }
        val now = SimpleDateFormat("EEEE d MMMM yyyy HH:mm", Locale.ITALY).format(Date())
        val today = m.entries.filter { it.ts >= startOfDay(System.currentTimeMillis()) }
            .joinToString(", ") { SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(it.ts)) + " " + it.ml + " ml" }
        return """
Sei l'assistente dell'app Acqua, che aiuta a bere abbastanza acqua. Rispondi sempre in italiano, in modo breve e cordiale.
Rispondi SOLO con un oggetto JSON di questo tipo, senza altro testo:
{"reply":"messaggio breve per l'utente","actions":[]}
Azioni disponibili dentro "actions" (usale solo quando l'utente chiede di fare qualcosa):
{"type":"add","ml":330,"minutes_ago":0} aggiunge una bevuta (minutes_ago è opzionale)
{"type":"remove_last"} annulla l'ultima bevuta di oggi
{"type":"clear_today"} cancella tutte le bevute di oggi
{"type":"set_goal","ml":2500} imposta l'obiettivo giornaliero in ml
{"type":"set_profile","kg":70,"activity":1} peso in kg e attività 0 bassa, 1 media, 2 alta: ricalcola l'obiettivo
{"type":"set_reminders","enabled":true,"start":9,"end":22,"every_minutes":90,"quiet_enabled":true,"quiet_from":13,"quiet_to":14} promemoria: ore di inizio e fine, ogni tot minuti (da 30 a 360), pausa senza promemoria tra due ore (tutti i campi opzionali)
{"type":"propose_add","ml":330} propone una quantità stimata, che l'utente conferma con un pulsante
{"type":"save_favorite","name":"Borraccia","ml":750} salva una bevanda preferita (massimo 6)
{"type":"remove_favorite","name":"Borraccia"} elimina un preferito
{"type":"set_theme","value":0} tema 0 sistema, 1 chiaro, 2 scuro
{"type":"sync"} sincronizza con Google Drive
{"type":"export_pdf","days":30} crea il report PDF e apre la condivisione; al posto di days si può usare "period":"this_month" oppure "period":"last_month"
{"type":"export_csv","days":30} come sopra ma in CSV
Se l'utente allega una foto di una bevanda, bottiglia, bicchiere, lattina o prodotto, stima il volume in ml.
Usa come fonte più precisa la quantità scritta sull'etichetta o i dati del database dei prodotti forniti nel messaggio; se mancano, stima dalle proporzioni rispetto a oggetti noti e indica un intervallo.
Se la quantità è certa (scritta sull'etichetta, nei dati del database o detta dall'utente) e la bevanda è acqua o idratante, registra con add e di' quanti ml hai registrato.
Se la quantità è solo una tua stima dall'immagine, NON usare add: usa propose_add e nel reply spiega la stima con un intervallo; l'utente conferma con un pulsante.
Per le domande, i consigli o l'analisi dei dati lascia "actions" vuoto e rispondi nel campo reply.
Se la bevanda non è acqua (caffè, tè, birra, succo), registra solo una quantità ragionevole di liquido idratante e spiega la scelta.
Stato attuale dell'app:
Data e ora: $now
Obiettivo giornaliero: ${m.goalMl} ml
Bevuto oggi: ${m.todayMl()} ml (${today.ifEmpty { "nessuna bevuta" }})
Ultimi 7 giorni: $week
Promemoria: ${if (m.notify) "attivi" else "spenti"}, dalle ${m.startH} alle ${m.endH} ogni ${m.everyMin} minuti, pausa ${if (m.quietOn) "dalle ${m.quietFrom} alle ${m.quietTo}" else "non attiva"}
Preferiti: ${if (m.favs.isEmpty()) "nessuno" else m.favs.joinToString(", ") { it.first + " " + it.second + " ml" }}
Profilo: ${m.weight} kg, attività ${m.activity}
        """.trimIndent()
    }
}
