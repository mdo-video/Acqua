package app.acqua

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope

class MainActivity : ComponentActivity() {
    lateinit var model: Model

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        try {
            val res = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(r.data)
            sync(res.accessToken ?: "")
        } catch (e: Exception) {
            model.syncStatus = "Accesso annullato"
        }
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        model = Model(this)
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        Reminder.schedule(this)
        setContent { App(model, this) }
        if (model.linked) startSync()
        checkUpdate()
    }

    fun add(ml: Int) {
        model.entries = model.entries + Entry(System.currentTimeMillis(), ml)
        model.save()
        if (model.linked) startSync()
    }

    fun remove(e: Entry) {
        model.entries = model.entries - e
        model.deleted = model.deleted + e.ts
        model.save()
        if (model.linked) startSync()
    }

    fun startSync() {
        val req = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.appdata"))).build()
        Identity.getAuthorizationClient(this).authorize(req)
            .addOnSuccessListener { res ->
                if (res.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(res.pendingIntent!!.intentSender).build())
                } else sync(res.accessToken ?: "")
            }
            .addOnFailureListener { model.syncStatus = "Sync non disponibile: ${it.message}" }
    }

    private fun sync(token: String) {
        model.syncStatus = "Sincronizzo..."
        Thread {
            try {
                val r = Sync.run(token, model.entries, model.deleted)
                runOnUiThread {
                    model.deleted = model.deleted + r.second
                    model.entries = mergeEntries(r.first, model.entries).filter { it.ts !in model.deleted }
                    model.linked = true
                    model.save()
                    model.syncStatus = "Sincronizzato"
                }
            } catch (e: Exception) {
                runOnUiThread { model.syncStatus = "Errore sync: ${e.message}" }
            }
        }.start()
    }

    fun checkUpdate() {
        if (BuildConfig.GH_REPO.isEmpty()) { model.updStatus = "Repository non configurata"; return }
        model.updStatus = "Controllo..."
        Thread {
            try {
                val r = Update.latest(BuildConfig.GH_REPO)
                runOnUiThread {
                    if (r != null && r.first > BuildConfig.VERSION_CODE) {
                        model.updateUrl = r.second
                        model.updStatus = "Disponibile la versione 1.0.${r.first}"
                    } else model.updStatus = "App aggiornata"
                }
            } catch (e: Exception) {
                runOnUiThread { model.updStatus = "Errore: ${e.message}" }
            }
        }.start()
    }

    fun installUpdate() {
        val u = model.updateUrl ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            model.updStatus = "Consenti l'installazione e riprova"
            return
        }
        model.updStatus = "Download..."
        Thread {
            try {
                val f = Update.download(this, u)
                runOnUiThread { Update.install(this, f); model.updStatus = "" }
            } catch (e: Exception) {
                runOnUiThread { model.updStatus = "Errore: ${e.message}" }
            }
        }.start()
    }
}
