package app.acqua

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Media {
    fun load(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 1600) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val rot = try {
            cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
        } catch (e: Exception) {
            1
        }
        val deg = when (rot) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        val mx = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
    }

    fun base64(b: Bitmap): String {
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 80, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    // Cerca un codice a barre nella foto (da chiamare fuori dal thread principale)
    fun barcode(b: Bitmap): String? {
        val opts = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
            .build()
        val sc = BarcodeScanning.getClient(opts)
        return try {
            Tasks.await(sc.process(InputImage.fromBitmap(b, 0))).firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
        } catch (e: Exception) {
            null
        } finally {
            sc.close()
        }
    }

    // Cerca il prodotto su Open Food Facts e restituisce una descrizione testuale
    fun lookup(code: String): String {
        val url = "https://world.openfoodfacts.org/api/v2/product/$code.json?fields=product_name,brands,quantity,serving_size"
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "Acqua/1.0 (Android)")
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            if (o.optInt("status") != 1) {
                "Codice a barre $code letto, ma non è presente nel database Open Food Facts."
            } else {
                val pr = o.getJSONObject("product")
                "Codice a barre $code. Dati dal database Open Food Facts: nome \"" + pr.optString("product_name") +
                    "\", marca \"" + pr.optString("brands") + "\", quantità \"" + pr.optString("quantity") +
                    "\", porzione \"" + pr.optString("serving_size") + "\"."
            }
        } catch (e: Exception) {
            "Codice a barre $code letto, ma non sono riuscito a consultare il database."
        }
    }
}
