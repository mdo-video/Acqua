package app.acqua

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class WeeklyWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val m = Model.get(applicationContext)
        if (m.notify && m.profileDone) {
            val t = Badges.totals(m)
            val sf = SimpleDateFormat("yyyyMMdd", Locale.ITALY)
            val vals = (0..6).map { i ->
                val c = Calendar.getInstance()
                c.add(Calendar.DAY_OF_YEAR, -i)
                t[sf.format(c.time)] ?: 0
            }
            val ok = vals.count { it >= m.goalMl }
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("acqua_week", "Riepilogo settimanale", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(
                applicationContext, 2, Intent(applicationContext, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(applicationContext, "acqua_week")
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("La tua settimana")
                .setContentText("Media ${litri(vals.sum() / 7)} L al giorno, obiettivo raggiunto $ok giorni su 7. Serie: ${Badges.streak(m)}")
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(2, n)
        }
        Weekly.schedule(applicationContext)
        return Result.success()
    }
}

object Weekly {
    fun schedule(c: Context) {
        val m = Model.get(c)
        val wm = WorkManager.getInstance(c)
        if (!m.notify || !m.profileDone) { wm.cancelUniqueWork("week"); return }
        wm.enqueueUniqueWork(
            "week", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<WeeklyWorker>().setInitialDelay(delay(), TimeUnit.MILLISECONDS).build()
        )
    }

    private fun delay(): Long {
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance()
        c.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY)
        c.set(Calendar.HOUR_OF_DAY, 19); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= now + 60_000) c.add(Calendar.DAY_OF_YEAR, 7)
        return c.timeInMillis - now
    }
}
