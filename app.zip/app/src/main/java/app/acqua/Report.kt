package app.acqua

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Report {
    private const val W = 595
    private const val H = 842
    private val loc = Locale.ITALY

    private fun col(h: String) = Color.parseColor(h)

    private fun p(
        color: Int, size: Float = 12f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT
    ): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        textAlign = align
    }

    private fun footer(cv: Canvas, n: Int) {
        val grey = col("#41484D")
        cv.drawLine(40f, 800f, 555f, 800f, p(col("#DEE3EB")).apply { strokeWidth = 1f })
        cv.drawText(
            "Generato il " + SimpleDateFormat("d MMM yyyy HH:mm", loc).format(Date()) + " · App Acqua",
            40f, 820f, p(grey, 9f)
        )
        cv.drawText("Pagina $n/2", 555f, 820f, p(grey, 9f, align = Paint.Align.RIGHT))
    }

    fun build(ctx: Context, m: Model): File {
        val dark = col("#00395F")
        val primary = col("#00639B")
        val light = col("#7FB6DE")
        val card = col("#EAF3FB")
        val grey = col("#41484D")
        val orange = col("#E65100")

        val key = SimpleDateFormat("yyyyMMdd", loc)
        val totals = m.entries.groupBy { key.format(Date(it.ts)) }.mapValues { en -> en.value.sumOf { it.ml } }
        val days = (29 downTo 0).map { Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -it) }.time }
        val vals = days.map { totals[key.format(it)] ?: 0 }
        val goal = m.goalMl
        val total = vals.sum()
        val avg = total / 30
        val hit = vals.count { it >= goal }
        val bestIdx = vals.indices.maxByOrNull { vals[it] } ?: 0
        var streak = 0
        var si = 29
        if (vals[si] < goal) si--
        while (si >= 0 && vals[si] >= goal) { streak++; si-- }
        val last7 = vals.subList(23, 30).sum() / 7
        val prev7 = vals.subList(16, 23).sum() / 7
        val trend = if (prev7 > 0) (last7 - prev7) * 100 / prev7 else 0

        val doc = PdfDocument()

        // ---------- Pagina 1 ----------
        val pg1 = doc.startPage(PdfDocument.PageInfo.Builder(W, H, 1).create())
        val cv = pg1.canvas
        cv.drawRect(0f, 0f, W.toFloat(), 150f, p(dark))
        cv.save()
        cv.clipRect(0f, 0f, W.toFloat(), 150f)
        cv.drawCircle(W - 50f, 30f, 110f, p(Color.argb(40, 152, 203, 255)))
        cv.drawCircle(W - 170f, 150f, 70f, p(Color.argb(30, 152, 203, 255)))
        cv.restore()
        cv.drawText("Report idratazione", 40f, 72f, p(Color.WHITE, 30f, true))
        cv.drawText("Acqua · ultimi 30 giorni", 40f, 98f, p(col("#CDE5FF"), 14f))
        val df = SimpleDateFormat("d MMM yyyy", loc)
        cv.drawText(df.format(days.first()) + " - " + df.format(days.last()), 40f, 122f, p(col("#98CBFF"), 12f))

        val labels = listOf("Media giornaliera", "Obiettivo", "Giorni in target", "Totale bevuto")
        val values = listOf(litri(avg) + " L", litri(goal) + " L", "$hit/30", litri(total) + " L")
        val cw = (W - 80 - 36) / 4f
        for (k in 0..3) {
            val x = 40 + k * (cw + 12)
            cv.drawRoundRect(RectF(x, 175f, x + cw, 255f), 14f, 14f, p(card))
            cv.drawText(labels[k], x + 12, 200f, p(grey, 10f))
            cv.drawText(values[k], x + 12, 235f, p(primary, 22f, true))
        }

        cv.drawText("Andamento giornaliero", 40f, 298f, p(dark, 16f, true))
        val cx0 = 70f
        val cx1 = 555f
        val cy0 = 330f
        val cy1 = 560f
        val top = ((maxOf(goal, vals.max()) + 999) / 1000) * 1000
        val steps = top / 1000
        for (g in 0..steps) {
            val y = cy1 - (cy1 - cy0) * g / steps
            cv.drawLine(cx0, y, cx1, y, p(col("#DEE3EB")).apply { strokeWidth = 1f })
            cv.drawText("$g L", cx0 - 8, y + 3, p(grey, 9f, align = Paint.Align.RIGHT))
        }
        val slot = (cx1 - cx0) / 30f
        days.forEachIndexed { idx, d ->
            val bh = (cy1 - cy0) * vals[idx] / top
            val x = cx0 + idx * slot + (slot - 11f) / 2
            val barColor = if (vals[idx] >= goal) primary else light
            if (bh > 0f) cv.drawRoundRect(RectF(x, cy1 - bh, x + 11f, cy1), 3f, 3f, p(barColor))
            if (idx % 5 == 0 || idx == 29) {
                cv.drawText(
                    SimpleDateFormat("d", loc).format(d), x + 5.5f, cy1 + 14f,
                    p(grey, 9f, align = Paint.Align.CENTER)
                )
            }
        }
        val gy = cy1 - (cy1 - cy0) * goal / top
        val dash = p(orange).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
        }
        cv.drawLine(cx0, gy, cx1, gy, dash)

        cv.drawRoundRect(RectF(40f, 590f, 52f, 602f), 3f, 3f, p(primary))
        cv.drawText("Obiettivo raggiunto", 58f, 600f, p(grey, 10f))
        cv.drawRoundRect(RectF(190f, 590f, 202f, 602f), 3f, 3f, p(light))
        cv.drawText("Sotto obiettivo", 208f, 600f, p(grey, 10f))
        cv.drawLine(320f, 596f, 340f, 596f, dash)
        cv.drawText("Obiettivo " + litri(goal) + " L", 346f, 600f, p(grey, 10f))

        cv.drawText("Punti salienti", 40f, 645f, p(dark, 16f, true))
        val dayFmt = SimpleDateFormat("EEEE d MMMM", loc)
        val trendTxt = if (prev7 > 0) " (" + (if (trend >= 0) "+" else "") + trend + "% rispetto ai 7 precedenti)" else ""
        val rows = listOf(
            "Giorno migliore: " + dayFmt.format(days[bestIdx]) + " con " + litri(vals[bestIdx]) + " L",
            "Serie di giorni consecutivi in target: $streak",
            "Ultimi 7 giorni: media " + litri(last7) + " L al giorno" + trendTxt
        )
        val dots = listOf(primary, col("#2E7D32"), orange)
        rows.forEachIndexed { r, t ->
            val y = 665f + r * 42f
            cv.drawRoundRect(RectF(40f, y, 555f, y + 34f), 12f, 12f, p(card))
            cv.drawCircle(60f, y + 17f, 6f, p(dots[r]))
            cv.drawText(t, 78f, y + 21f, p(Color.BLACK, 11f))
        }
        footer(cv, 1)
        doc.finishPage(pg1)

        // ---------- Pagina 2 ----------
        val pg2 = doc.startPage(PdfDocument.PageInfo.Builder(W, H, 2).create())
        val c2 = pg2.canvas
        c2.drawRect(0f, 0f, W.toFloat(), 90f, p(dark))
        c2.drawText("Dettaglio giornaliero", 40f, 56f, p(Color.WHITE, 24f, true))
        c2.drawText("Dal più recente · obiettivo " + litri(goal) + " L", 40f, 76f, p(col("#CDE5FF"), 11f))
        c2.drawText("Giorno", 48f, 116f, p(primary, 10f, true))
        c2.drawText("Bevuto", 190f, 116f, p(primary, 10f, true))
        c2.drawText("Obiettivo", 290f, 116f, p(primary, 10f, true))
        val dayShort = SimpleDateFormat("EEE d MMM", loc)
        for (r in 0..29) {
            val idx = 29 - r
            val v = vals[idx]
            val y = 126f + r * 21f
            if (r % 2 == 0) c2.drawRect(40f, y, 555f, y + 21f, p(card))
            c2.drawText(dayShort.format(days[idx]).replaceFirstChar { it.uppercase() }, 48f, y + 14.5f, p(Color.BLACK, 10f))
            c2.drawText(litri(v) + " L", 190f, y + 14.5f, p(Color.BLACK, 10f, true))
            c2.drawRoundRect(RectF(290f, y + 6f, 490f, y + 15f), 4f, 4f, p(col("#DEE3EB")))
            val frac = (v.toFloat() / goal).coerceIn(0f, 1f)
            if (frac > 0f) c2.drawRoundRect(RectF(290f, y + 6f, 290f + 200f * frac, y + 15f), 4f, 4f, p(if (v >= goal) primary else light))
            c2.drawText((v * 100 / goal).toString() + "%", 547f, y + 14.5f, p(grey, 10f, align = Paint.Align.RIGHT))
        }
        footer(c2, 2)
        doc.finishPage(pg2)

        val f = File(ctx.cacheDir, "Acqua-report.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
