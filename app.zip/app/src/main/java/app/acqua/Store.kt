package app.acqua

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Entry(val ts: Long, val ml: Int)

fun startOfDay(ts: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ts
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun calcGoal(kg: Int, act: Int): Int = ((kg * 30 + listOf(0, 300, 600)[act]) / 100 * 100).coerceIn(1500, 4500)

fun entriesToJson(l: List<Entry>): JSONArray {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("t", it.ts).put("m", it.ml)) }
    return a
}

fun entriesFromJson(a: JSONArray): List<Entry> =
    (0 until a.length()).map { val o = a.getJSONObject(it); Entry(o.getLong("t"), o.getInt("m")) }

fun longsFromJson(a: JSONArray): Set<Long> = (0 until a.length()).map { a.getLong(it) }.toSet()

fun mergeEntries(a: List<Entry>, b: List<Entry>): List<Entry> = (a + b).distinctBy { it.ts }.sortedBy { it.ts }

class Model private constructor(c: Context) {
    private val ctx = c.applicationContext
    private val p = ctx.getSharedPreferences("acqua", Context.MODE_PRIVATE)
    var theme by mutableStateOf(p.getInt("theme", 0))
    var weight by mutableStateOf(p.getInt("weight", 70))
    var activity by mutableStateOf(p.getInt("activity", 1))
    var goalMl by mutableStateOf(p.getInt("goal", 2000))
    var profileDone by mutableStateOf(p.getBoolean("done", false))
    var startH by mutableStateOf(p.getInt("sh", 8))
    var endH by mutableStateOf(p.getInt("eh", 22))
    var every by mutableStateOf(p.getInt("ev", 2))
    var notify by mutableStateOf(p.getBoolean("nt", true))
    var linked by mutableStateOf(p.getBoolean("linked", false))
    var entries by mutableStateOf(entriesFromJson(JSONArray(p.getString("entries", "[]"))))
    var deleted by mutableStateOf(longsFromJson(JSONArray(p.getString("deleted", "[]"))))
    var syncStatus by mutableStateOf("")
    var updStatus by mutableStateOf("")
    var updateUrl by mutableStateOf<String?>(null)
    var aiKey by mutableStateOf(p.getString("ai", "") ?: "")
    var lastAdded by mutableStateOf<Entry?>(null)
    var aiBusy by mutableStateOf(false)
    var reportStatus by mutableStateOf("")
    val chat = mutableStateListOf<Pair<Boolean, String>>()

    fun save() {
        p.edit().putInt("theme", theme).putInt("weight", weight).putInt("activity", activity)
            .putInt("goal", goalMl).putBoolean("done", profileDone).putInt("sh", startH).putInt("eh", endH)
            .putInt("ev", every).putBoolean("nt", notify).putBoolean("linked", linked)
            .putString("entries", entriesToJson(entries).toString())
            .putString("deleted", JSONArray(deleted.toList()).toString())
            .putString("ai", aiKey).apply()
        WaterWidget.refresh(ctx)
    }

    fun addEntry(ml: Int, ts: Long = System.currentTimeMillis()): Entry {
        val e = Entry(ts, ml)
        entries = entries + e
        save()
        return e
    }

    companion object {
        @Volatile private var inst: Model? = null
        fun get(c: Context): Model = inst ?: synchronized(this) { inst ?: Model(c).also { inst = it } }
    }

    fun todayMl(): Int {
        val s = startOfDay(System.currentTimeMillis())
        return entries.filter { it.ts >= s }.sumOf { it.ml }
    }
}
