package app.acqua

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Entry(val ts: Long, val ml: Int)

fun startOfDay(ts: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ts
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun calcGoal(kg: Int, act: Int): Int = ((kg * 30 + listOf(0, 300, 600)[act]) / 100 * 100).coerceIn(1500, 4500)

fun entriesToJson(l: List<Entry>): JSONArray {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("t", it.ts).put("m", it.ml)) }
    return a
}

fun entriesFromJson(a: JSONArray): List<Entry> =
    (0 until a.length()).map { val o = a.getJSONObject(it); Entry(o.getLong("t"), o.getInt("m")) }

fun longsFromJson(a: JSONArray): Set<Long> = (0 until a.length()).map { a.getLong(it) }.toSet()

fun mergeEntries(a: List<Entry>, b: List<Entry>): List<Entry> = (a + b).distinctBy { it.ts }.sortedBy { it.ts }

data class Conv(val id: Long, val title: String, val ts: Long, val msgs: List<Pair<Boolean, String>>)

class Model private constructor(c: Context) {
    private val ctx = c.applicationContext
    private val p = ctx.getSharedPreferences("acqua", Context.MODE_PRIVATE)
    var theme by mutableStateOf(p.getInt("theme", 0))
    var weight by mutableStateOf(p.getInt("weight", 70))
    var activity by mutableStateOf(p.getInt("activity", 1))
    var goalMl by mutableStateOf(p.getInt("goal", 2000))
    var profileDone by mutableStateOf(p.getBoolean("done", false))
    var startH by mutableStateOf(p.getInt("sh", 8))
    var endH by mutableStateOf(p.getInt("eh", 22))
    var every by mutableStateOf(p.getInt("ev", 2))
    var notify by mutableStateOf(p.getBoolean("nt", true))
    var linked by mutableStateOf(p.getBoolean("linked", false))
    var entries by mutableStateOf(entriesFromJson(JSONArray(p.getString("entries", "[]"))))
    var deleted by mutableStateOf(longsFromJson(JSONArray(p.getString("deleted", "[]"))))
    var syncStatus by mutableStateOf("")
    var updStatus by mutableStateOf("")
    var updateUrl by mutableStateOf<String?>(null)
    var aiKey by mutableStateOf(p.getString("ai", "") ?: "")
    var lastAdded by mutableStateOf<Entry?>(null)
    var aiBusy by mutableStateOf(false)
    var reportStatus by mutableStateOf("")
    var pendingPhoto by mutableStateOf<Bitmap?>(null)
    val chat = mutableStateListOf<Pair<Boolean, String>>()
    var convs by mutableStateOf(loadConvs())
    var curId by mutableStateOf(p.getLong("cur", 0L))

    init {
        convs.firstOrNull { it.id == curId }?.let { chat.addAll(it.msgs) }
    }

    private fun loadConvs(): List<Conv> = try {
        val a = JSONArray(p.getString("convs", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val ms = o.getJSONArray("m")
            Conv(
                o.getLong("id"), o.getString("t"), o.getLong("ts"),
                (0 until ms.length()).map { j ->
                    val x = ms.getJSONArray(j)
                    (x.getInt(0) == 1) to x.getString(1)
                }
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveConvs() {
        val a = JSONArray()
        convs.forEach { c ->
            val ms = JSONArray()
            c.msgs.forEach { (u, t) -> ms.put(JSONArray().put(if (u) 1 else 0).put(t)) }
            a.put(JSONObject().put("id", c.id).put("t", c.title).put("ts", c.ts).put("m", ms))
        }
        p.edit().putString("convs", a.toString()).putLong("cur", curId).apply()
    }

    fun addMsg(user: Boolean, t: String) {
        chat.add(user to t)
        saveChat()
    }

    fun saveChat() {
        if (chat.isEmpty()) return
        if (curId == 0L) curId = System.currentTimeMillis()
        val first = chat.firstOrNull { it.first }?.second ?: "Chat"
        val title = first.removePrefix("📷 ").trim().take(40).ifBlank { "Chat" }
        val c = Conv(curId, title, System.currentTimeMillis(), chat.toList().takeLast(200))
        convs = (listOf(c) + convs.filter { it.id != curId }).take(50)
        saveConvs()
    }

    fun newChat() {
        saveChat()
        chat.clear()
        pendingPhoto = null
        curId = 0L
        saveConvs()
    }

    fun openChat(id: Long) {
        saveChat()
        val c = convs.firstOrNull { it.id == id } ?: return
        chat.clear()
        chat.addAll(c.msgs)
        pendingPhoto = null
        curId = id
        saveConvs()
    }

    fun deleteChat(id: Long) {
        convs = convs.filter { it.id != id }
        if (curId == id) {
            chat.clear()
            curId = 0L
        }
        saveConvs()
    }

    fun save() {
        p.edit().putInt("theme", theme).putInt("weight", weight).putInt("activity", activity)
            .putInt("goal", goalMl).putBoolean("done", profileDone).putInt("sh", startH).putInt("eh", endH)
            .putInt("ev", every).putBoolean("nt", notify).putBoolean("linked", linked)
            .putString("entries", entriesToJson(entries).toString())
            .putString("deleted", JSONArray(deleted.toList()).toString())
            .putString("ai", aiKey).apply()
        WaterWidget.refresh(ctx)
    }

    fun addEntry(ml: Int, ts: Long = System.currentTimeMillis()): Entry {
        val e = Entry(ts, ml)
        entries = entries + e
        save()
        return e
    }

    companion object {
        @Volatile private var inst: Model? = null
        fun get(c: Context): Model = inst ?: synchronized(this) { inst ?: Model(c).also { inst = it } }
    }

    fun todayMl(): Int {
        val s = startOfDay(System.currentTimeMillis())
        return entries.filter { it.ts >= s }.sumOf { it.ml }
    }
}
