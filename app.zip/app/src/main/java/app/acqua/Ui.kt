package app.acqua

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Light = lightColorScheme(
    primary = Color(0xFF00639B), onPrimary = Color.White,
    primaryContainer = Color(0xFFCDE5FF), onPrimaryContainer = Color(0xFF001D32),
    background = Color(0xFFFDFCFF), surface = Color(0xFFFDFCFF),
    onBackground = Color(0xFF1A1C1E), onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFDEE3EB), onSurfaceVariant = Color(0xFF41484D),
    surfaceContainer = Color(0xFFF0F4F9)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF98CBFF), onPrimary = Color(0xFF003354),
    primaryContainer = Color(0xFF004A77), onPrimaryContainer = Color(0xFFCDE5FF),
    background = Color(0xFF1A1C1E), surface = Color(0xFF1A1C1E),
    onBackground = Color(0xFFE2E2E6), onSurface = Color(0xFFE2E2E6),
    surfaceVariant = Color(0xFF41484D), onSurfaceVariant = Color(0xFFC1C7CE),
    surfaceContainer = Color(0xFF24272A)
)

@Composable
fun App(m: Model, a: MainActivity) {
    val dark = when (m.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            var tab by remember { mutableStateOf(0) }
            var edit by remember { mutableStateOf(false) }
            if (!m.profileDone || edit) {
                Profile(m, first = !m.profileDone) { edit = false }
            } else {
                val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        if (!imeOpen) NavigationBar {
                            listOf(
                                "Oggi" to Icons.Default.Home,
                                "Storico" to Icons.Default.DateRange,
                                "AI" to Icons.Default.Star,
                                "Impostazioni" to Icons.Default.Settings
                            ).forEachIndexed { i, (t, ic) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Icon(ic, contentDescription = null) }, label = { Text(t) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> Today(m, a)
                            1 -> History(m)
                            2 -> Assistant(m, a)
                            else -> Options(m, a) { edit = true }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Profile(m: Model, first: Boolean, done: () -> Unit) {
    val c = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var kg by remember { mutableStateOf(m.weight.toString()) }
    var act by remember { mutableStateOf(m.activity) }
    val w = kg.toIntOrNull()?.coerceIn(30, 200) ?: 70
    val goal = calcGoal(w, act)
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Il tuo profilo", style = MaterialTheme.typography.headlineMedium)
        Text("Calcoliamo il tuo obiettivo giornaliero", color = cs.onSurfaceVariant)
        OutlinedTextField(
            value = kg, onValueChange = { kg = it.filter(Char::isDigit).take(3) },
            label = { Text("Peso (kg)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Text("Attività fisica")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Bassa", "Media", "Alta").forEachIndexed { i, t ->
                FilterChip(selected = act == i, onClick = { act = i }, label = { Text(t) })
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp)) {
                Text("Obiettivo giornaliero")
                Text("${litri(goal)} L", style = MaterialTheme.typography.displaySmall)
                Text("Modificabile in ogni momento")
            }
        }
        Button(
            onClick = {
                m.weight = w; m.activity = act; m.goalMl = goal; m.profileDone = true
                m.save(); Reminder.schedule(c); done()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) { Text("Continua") }
        if (first) {
            TextButton(
                onClick = { m.goalMl = 2000; m.profileDone = true; m.save(); Reminder.schedule(c); done() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Salta (usa 2 L)") }
        } else {
            TextButton(onClick = done, modifier = Modifier.fillMaxWidth()) { Text("Annulla") }
        }
    }
}

@Composable
fun Today(m: Model, a: MainActivity) {
    val cs = MaterialTheme.colorScheme
    val done = m.todayMl()
    val prog by animateFloatAsState((done.toFloat() / m.goalMl).coerceIn(0f, 1f), label = "p")
    val s = startOfDay(System.currentTimeMillis())
    val hm = SimpleDateFormat("HH:mm", Locale.ITALY)
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState())) {
        Text(
            SimpleDateFormat("EEEE d MMMM", Locale.ITALY).format(Date()).replaceFirstChar { it.uppercase() },
            color = cs.onSurfaceVariant
        )
        Text("Oggi", style = MaterialTheme.typography.headlineMedium)
        Box(
            Modifier.align(Alignment.CenterHorizontally).padding(top = 16.dp).size(220.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                progress = { prog }, modifier = Modifier.fillMaxSize(), strokeWidth = 16.dp,
                color = cs.primary, trackColor = cs.primaryContainer, strokeCap = StrokeCap.Round
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${litri(done)} L", style = MaterialTheme.typography.displaySmall)
                Text("su ${litri(m.goalMl)} L", color = cs.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(150, 250, 500).forEach { ml ->
                val mod = Modifier.weight(1f).height(48.dp)
                if (ml == 250) Button(onClick = { a.add(ml) }, modifier = mod) { Text("+$ml ml") }
                else OutlinedButton(onClick = { a.add(ml) }, modifier = mod) { Text("+$ml ml") }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            var custom by remember { mutableStateOf("") }
            OutlinedTextField(
                value = custom, onValueChange = { custom = it.filter(Char::isDigit).take(4) },
                label = { Text("Altro (ml)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    val v = custom.toIntOrNull()
                    if (v != null && v in 1..5000) { a.add(v); custom = "" }
                },
                modifier = Modifier.height(48.dp)
            ) { Text("Aggiungi") }
        }
        m.lastAdded?.let { last ->
            LaunchedEffect(last) {
                delay(6000)
                if (m.lastAdded == last) m.lastAdded = null
            }
            Surface(
                shape = RoundedCornerShape(12.dp), color = cs.surfaceContainer,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) {
                Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Aggiunti ${last.ml} ml", Modifier.weight(1f))
                    TextButton(onClick = { a.remove(last) }) { Text("Annulla") }
                }
            }
        }
        if (m.notify) {
            Card(
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer),
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Prossimo promemoria", Modifier.weight(1f))
                    Text(Reminder.nextTime(m), style = MaterialTheme.typography.titleLarge)
                }
            }
        }
        Text("Bevute di oggi", Modifier.padding(top = 20.dp, bottom = 4.dp), color = cs.onSurfaceVariant)
        m.entries.filter { it.ts >= s }.sortedByDescending { it.ts }.forEach { e ->
            Surface(
                shape = RoundedCornerShape(12.dp), color = cs.surfaceContainer,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            ) {
                Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${e.ml} ml", Modifier.weight(1f))
                    Text(hm.format(Date(e.ts)), color = cs.onSurfaceVariant)
                    IconButton(onClick = { a.remove(e) }) { Icon(Icons.Default.Delete, contentDescription = "Elimina") }
                }
            }
        }
    }
}

@Composable
fun History(m: Model) {
    val cs = MaterialTheme.colorScheme
    var range by remember { mutableStateOf(7) }
    val f = SimpleDateFormat("yyyyMMdd", Locale.ITALY)
    val totals = m.entries.groupBy { f.format(Date(it.ts)) }.mapValues { en -> en.value.sumOf { it.ml } }
    val days = ((range - 1) downTo 0).map { Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -it) }.time }
    val vals = days.map { totals[f.format(it)] ?: 0 }
    val top = maxOf(m.goalMl, vals.max()).toFloat()
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState())) {
        Text("Storico", style = MaterialTheme.typography.headlineMedium)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 30).forEach { r ->
                FilterChip(selected = range == r, onClick = { range = r }, label = { Text("$r giorni") })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 24.dp).height(190.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            days.forEachIndexed { i, d ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxWidth(if (range == 7) 0.6f else 0.7f).height((150f * vals[i] / top).dp + 2.dp)
                            .background(
                                if (vals[i] >= m.goalMl) cs.primary else cs.primary.copy(alpha = 0.45f),
                                RoundedCornerShape(if (range == 7) 6.dp else 2.dp)
                            )
                    )
                    Text(
                        if (range == 7) SimpleDateFormat("EEE", Locale.ITALY).format(d).take(3)
                        else if (i % 5 == 0) SimpleDateFormat("d", Locale.ITALY).format(d) else " ",
                        color = cs.onSurfaceVariant, softWrap = false, overflow = TextOverflow.Visible,
                        style = if (range == 7) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
        Text("Media: ${litri(vals.sum() / range)} L al giorno", Modifier.padding(top = 24.dp))
        Text("Obiettivo raggiunto: ${vals.count { it >= m.goalMl }} giorni su $range")
    }
}

@Composable
fun Sect(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title, style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp)
        )
        Surface(
            shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
        }
    }
}

@Composable
fun Step(label: String, value: String, minus: () -> Unit, plus: () -> Unit, enabled: Boolean = true) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = if (enabled) cs.onSurface else cs.onSurfaceVariant.copy(alpha = 0.5f))
        Surface(shape = RoundedCornerShape(50), color = cs.surfaceVariant.copy(alpha = if (enabled) 0.6f else 0.3f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = minus, enabled = enabled, modifier = Modifier.size(40.dp)) {
                    Text("−", style = MaterialTheme.typography.titleLarge)
                }
                Text(value, Modifier.width(60.dp), textAlign = TextAlign.Center)
                IconButton(onClick = plus, enabled = enabled, modifier = Modifier.size(40.dp)) {
                    Text("+", style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}

@Composable
fun Options(m: Model, a: MainActivity, editProfile: () -> Unit) {
    val c = LocalContext.current
    val cs = MaterialTheme.colorScheme
    fun commit() { m.save(); Reminder.schedule(c) }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Impostazioni", style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(top = 24.dp, start = 4.dp)
        )
        Sect("Tema") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Sistema", "Chiaro", "Scuro").forEachIndexed { i, t ->
                    FilterChip(selected = m.theme == i, onClick = { m.theme = i; m.save() }, label = { Text(t) })
                }
            }
        }
        Sect("Obiettivo") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${litri(m.goalMl)} L al giorno", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                OutlinedButton(onClick = editProfile) { Text("Modifica profilo") }
            }
        }
        Sect("Promemoria") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notifiche", Modifier.weight(1f))
                Switch(checked = m.notify, onCheckedChange = { m.notify = it; commit() })
            }
            Step("Dalle", "%02d:00".format(m.startH),
                { if (m.startH > 5) { m.startH--; commit() } },
                { if (m.startH < m.endH - 1) { m.startH++; commit() } }, enabled = m.notify)
            Step("Alle", "%02d:00".format(m.endH),
                { if (m.endH > m.startH + 1) { m.endH--; commit() } },
                { if (m.endH < 23) { m.endH++; commit() } }, enabled = m.notify)
            Step("Ogni", "${m.every} h",
                { if (m.every > 1) { m.every--; commit() } },
                { if (m.every < 6) { m.every++; commit() } }, enabled = m.notify)
            if (m.notify) {
                Text("Prossimo promemoria alle ${Reminder.nextTime(m)}", color = cs.onSurfaceVariant)
            }
        }
        Sect("Report") {
            Text("PDF con grafico e dettaglio degli ultimi 30 giorni", color = cs.onSurfaceVariant)
            if (m.reportStatus.isNotEmpty()) Text(m.reportStatus, color = cs.onSurfaceVariant)
            Button(onClick = { a.exportPdf() }) { Text("Esporta report PDF") }
        }
        Sect("Assistente AI (Gemini)") {
            OutlinedTextField(
                value = m.aiKey, onValueChange = { m.aiKey = it.trim(); m.save() },
                label = { Text("Chiave API") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Text("Incolla qui la chiave API di Google AI Studio", color = cs.onSurfaceVariant)
        }
        Sect("Account Google") {
            if (m.syncStatus.isNotEmpty()) Text(m.syncStatus, color = cs.onSurfaceVariant)
            Button(onClick = { a.startSync() }) { Text(if (m.linked) "Sincronizza ora" else "Accedi e sincronizza") }
        }
        Sect("App") {
            Text("Versione ${BuildConfig.VERSION_NAME}")
            if (m.updStatus.isNotEmpty()) Text(m.updStatus, color = cs.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { a.checkUpdate() }) { Text("Controlla aggiornamenti") }
                if (m.updateUrl != null) Button(onClick = { a.installUpdate() }) { Text("Installa") }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun Assistant(m: Model, a: MainActivity) {
    val cs = MaterialTheme.colorScheme
    var text by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    LaunchedEffect(m.chat.size, m.aiBusy) { scroll.animateScrollTo(scroll.maxValue) }
    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 24.dp).padding(top = 24.dp)) {
        Text("Assistente", style = MaterialTheme.typography.headlineMedium)
        Text(
            if (m.aiKey.isBlank()) "Inserisci la chiave API in Impostazioni"
            else "Scrivi cosa hai bevuto o chiedi di cambiare qualcosa",
            color = cs.onSurfaceVariant
        )
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            m.chat.forEach { (user, t) ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (user) cs.primaryContainer else cs.surfaceContainer,
                    modifier = Modifier.fillMaxWidth(0.85f).align(if (user) Alignment.End else Alignment.Start)
                ) { Text(t, Modifier.padding(12.dp)) }
            }
            if (m.aiBusy) Text("...", color = cs.onSurfaceVariant)
        }
        Row(Modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                placeholder = { Text("Es. ho bevuto 330 ml") }, maxLines = 3,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = { a.listen() }, enabled = !m.aiBusy,
                contentPadding = PaddingValues(horizontal = 14.dp), modifier = Modifier.height(48.dp)
            ) { Text("🎤") }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = { if (text.isNotBlank()) { a.askAi(text.trim()); text = "" } },
                enabled = !m.aiBusy, modifier = Modifier.height(48.dp)
            ) { Text("Invia") }
        }
    }
}
