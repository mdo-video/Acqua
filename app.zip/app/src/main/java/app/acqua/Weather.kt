package app.acqua

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

object Weather {
    @SuppressLint("MissingPermission")
    fun tempMax(c: Context): Int? {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = c.getSystemService(LocationManager::class.java)
        val loc = lm.getProviders(true)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
            .maxByOrNull { it.time } ?: return null
        val u = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
            "&daily=temperature_2m_max&timezone=auto&forecast_days=1"
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 10000
        con.readTimeout = 10000
        val j = JSONObject(con.inputStream.bufferedReader().readText())
        return j.getJSONObject("daily").getJSONArray("temperature_2m_max").getDouble(0).roundToInt()
    }
}
