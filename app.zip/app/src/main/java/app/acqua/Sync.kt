package app.acqua

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Sync {
    private const val B = "https://www.googleapis.com"

    fun run(token: String, local: List<Entry>, del: Set<Long>): Pair<List<Entry>, Set<Long>> {
        val q = URLEncoder.encode("name='acqua.json'", "UTF-8")
        val files = JSONObject(http("GET", "$B/drive/v3/files?spaces=appDataFolder&q=$q&fields=files(id)", token, null))
            .getJSONArray("files")
        val ids = (0 until files.length()).map { files.getJSONObject(it).getString("id") }
        var e = local
        var d = del
        for (id in ids) {
            val r = JSONObject(http("GET", "$B/drive/v3/files/$id?alt=media", token, null))
            e = e + entriesFromJson(r.getJSONArray("e"))
            d = d + longsFromJson(r.getJSONArray("d"))
        }
        e = e.distinctBy { it.ts }.filter { it.ts !in d }.sortedBy { it.ts }
        val content = JSONObject().put("e", entriesToJson(e)).put("d", JSONArray(d.toList())).toString()
        if (ids.isEmpty()) {
            create(token, content)
        } else {
            try {
                http(
                    "POST", "$B/upload/drive/v3/files/${ids[0]}?uploadType=media", token, content,
                    "application/json", mapOf("X-HTTP-Method-Override" to "PATCH")
                )
                ids.drop(1).forEach { http("DELETE", "$B/drive/v3/files/$it", token, null) }
            } catch (ex: Exception) {
                create(token, content)
                ids.forEach { http("DELETE", "$B/drive/v3/files/$it", token, null) }
            }
        }
        return e to d
    }

    private fun create(token: String, content: String) {
        val meta = JSONObject().put("name", "acqua.json").put("parents", JSONArray().put("appDataFolder")).toString()
        val bd = "acqua_bd"
        val body = "--$bd\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
            "--$bd\r\nContent-Type: application/json\r\n\r\n$content\r\n--$bd--"
        http("POST", "$B/upload/drive/v3/files?uploadType=multipart", token, body, "multipart/related; boundary=$bd")
    }

    private fun http(
        method: String, url: String, token: String, body: String?,
        ct: String = "application/json", extra: Map<String, String> = emptyMap()
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", ct)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code < 400) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        if (code >= 400) throw Exception("HTTP $code")
        return txt
    }
}
