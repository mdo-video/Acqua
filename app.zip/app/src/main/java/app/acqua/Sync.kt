package app.acqua

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class SyncData(val entries: List<Entry>, val deleted: Set<Long>, val convs: List<Conv>, val delConvs: Set<Long>)

object Sync {
    private const val B = "https://www.googleapis.com"

    fun run(token: String, local: SyncData): SyncData {
        val q = URLEncoder.encode("name='acqua.json'", "UTF-8")
        val files = JSONObject(http("GET", "$B/drive/v3/files?spaces=appDataFolder&q=$q&fields=files(id)", token, null))
            .getJSONArray("files")
        val ids = (0 until files.length()).map { files.getJSONObject(it).getString("id") }
        var e = local.entries
        var d = local.deleted
        var cs = local.convs
        var dc = local.delConvs
        for (id in ids) {
            val r = JSONObject(http("GET", "$B/drive/v3/files/$id?alt=media", token, null))
            e = e + entriesFromJson(r.getJSONArray("e"))
            d = d + longsFromJson(r.getJSONArray("d"))
            r.optJSONArray("c")?.let { cs = cs + convsFromJson(it) }
            r.optJSONArray("dc")?.let { dc = dc + longsFromJson(it) }
        }
        e = e.distinctBy { it.ts }.filter { it.ts !in d }.sortedBy { it.ts }
        val byId = HashMap<Long, Conv>()
        cs.forEach { c ->
            if (c.id !in dc) {
                val o = byId[c.id]
                if (o == null || c.ts > o.ts) byId[c.id] = c
            }
        }
        cs = byId.values.sortedByDescending { it.ts }.take(50)
        val content = JSONObject().put("e", entriesToJson(e)).put("d", JSONArray(d.toList()))
            .put("c", convsToJson(cs)).put("dc", JSONArray(dc.toList())).toString()
        if (ids.isEmpty()) {
            create(token, content)
        } else {
            try {
                http(
                    "POST", "$B/upload/drive/v3/files/${ids[0]}?uploadType=media", token, content,
                    "application/json", mapOf("X-HTTP-Method-Override" to "PATCH")
                )
                ids.drop(1).forEach { http("DELETE", "$B/drive/v3/files/$it", token, null) }
            } catch (ex: Exception) {
                create(token, content)
                ids.forEach { http("DELETE", "$B/drive/v3/files/$it", token, null) }
            }
        }
        return SyncData(e, d, cs, dc)
    }

    private fun create(token: String, content: String) {
        val meta = JSONObject().put("name", "acqua.json").put("parents", JSONArray().put("appDataFolder")).toString()
        val bd = "acqua_bd"
        val body = "--$bd\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
            "--$bd\r\nContent-Type: application/json\r\n\r\n$content\r\n--$bd--"
        http("POST", "$B/upload/drive/v3/files?uploadType=multipart", token, body, "multipart/related; boundary=$bd")
    }

    private fun http(
        method: String, url: String, token: String, body: String?,
        ct: String = "application/json", extra: Map<String, String> = emptyMap()
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", ct)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code < 400) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        if (code >= 400) throw Exception("HTTP $code")
        return txt
    }
}
