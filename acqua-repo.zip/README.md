Acqua: carica app.zip su GitHub, la build parte da sola.
